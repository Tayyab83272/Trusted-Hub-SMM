// --- Data Structure (Updated with 'More' Service) ---
const servicesData = {
    instagram: { icon: '📸', name: 'Instagram', color: 'bg-pink-500 text-white', services: {
        followers: { label: 'Followers', prompt: 'Profile URL' },
        likes: { label: 'Likes', prompt: 'Post URL' },
        views: { label: 'Video Views/Reels', prompt: 'Video/Reel URL' },
    }},
    youtube: { icon: '▶️', name: 'YouTube', color: 'bg-red-600 text-white', services: {
        views: { label: 'Views', prompt: 'Video URL' },
        subscribers: { label: 'Subscribers', prompt: 'Channel URL' },
        likes: { label: 'Likes', prompt: 'Video URL' },
    }},
    tiktok: { icon: '🎵', name: 'TikTok', color: 'bg-black text-white', services: {
        followers: { label: 'Followers', prompt: 'Profile URL' },
        views: { label: 'Video Views', prompt: 'Video URL' },
        shares: { label: 'Shares', prompt: 'Video URL' },
    }},
    facebook: { icon: '💙', name: 'Facebook', color: 'bg-blue-700 text-white', services: {
        likes: { label: 'Page Likes', prompt: 'Page URL' },
        followers: { label: 'Followers', prompt: 'Profile/Page URL' },
        post_likes: { label: 'Post Likes/Reactions', prompt: 'Post URL' },
    }},
    twitter: { icon: '🐦', name: 'Twitter (X)', color: 'bg-gray-800 text-white', services: {
        followers: { label: 'Followers', prompt: 'Profile URL' },
        likes: { label: 'Likes', prompt: 'Tweet URL' },
        views: { label: 'Video Views', prompt: 'Video/Post URL' },
    }},
    snapchat: { icon: '👻', name: 'Snapchat', color: 'bg-yellow-400 text-gray-900', services: {
        followers: { label: 'Followers/Subscribers', prompt: 'Profile Link' },
        views: { label: 'Story Views', prompt: 'Story Link' },
        swipe_ups: { label: 'Swipe Ups (Traffic)', prompt: 'Snap Ad/Story Link' },
    }},
    snakevideo: { icon: '🐍', name: 'Snack Video', color: 'bg-purple-600 text-white', services: {
        followers: { label: 'Followers', prompt: 'Profile Link' },
        views: { label: 'Video Views', prompt: 'Video URL' },
        likes: { label: 'Likes', prompt: 'Video URL' },
    }},
    webtraffic: { icon: '🌍', name: 'Website Traffic', color: 'bg-green-600 text-white', services: {
        premium: { label: 'Premium Traffic', prompt: 'Website/Blog URL' },
        geo: { label: 'Country-Based Traffic', prompt: 'Website URL' },
        clicks: { label: 'Clicks/Engagement', prompt: 'Page URL' },
    }},
    
    // --- New 'More' Service Added Below ---
    more: { icon: '➕', name: 'More (Other Service)', color: 'bg-gray-500 text-white', services: {
        // Sirf ek generic service rakhi hai, jiska prompt zyada descriptive hoga
        other_service: { 
            label: 'Other Social Media / Service', 
            prompt: 'Service Ka Naam (Jaise: Reddit Upvotes) Aur Link Yahan Daalein' 
        },
    }},
    // --- New 'More' Service Added Above ---
};

// --- State Management ---
let currentOrder = {
    platform: null,
    service: null,
};

// Messenger Link (User ka diya hua link)
const messengerLink = "https://m.me/tayyabkachannel?source=qr_link_share";

// --- UI/Step Control Functions ---
const showOrderView = () => {
    // Hides the landing page and shows the order form page
    document.getElementById('landing-view').classList.add('hidden');
    document.getElementById('order-view').classList.remove('hidden');
    renderPlatforms();
    // Smooth scroll to the top of the new view
    document.getElementById('order-view').scrollIntoView({ behavior: 'smooth' });
};

const updateStepIndicator = (step) => {
    const indicators = [1, 2, 3];
    indicators.forEach(s => {
        const el = document.getElementById(`step-${s}-indicator`);
        if (s <= step) {
            el.classList.remove('text-gray-400', 'border-gray-300');
            el.classList.add('text-yellow-500', 'border-yellow-500');
        } else {
            el.classList.remove('text-yellow-500', 'border-yellow-500');
            el.classList.add('text-gray-400', 'border-gray-300');
        }
    });
};

const showStepContent = (step) => {
    // Hides all steps and shows the required step content
    document.querySelectorAll('.step-content').forEach(el => el.classList.add('hidden'));
    const stepMap = { 1: 'step-1-platform', 2: 'step-2-service', 3: 'step-3-form' };
    document.getElementById(stepMap[step]).classList.remove('hidden');
    updateStepIndicator(step);
};

// --- Step 1: Platform Selection ---
const renderPlatforms = () => {
    const container = document.getElementById('platform-buttons');
    container.innerHTML = '';
    Object.keys(servicesData).forEach(key => {
        const data = servicesData[key];
        const isActive = currentOrder.platform === key;
        container.innerHTML += `
            <button onclick="selectPlatform('${key}')"
                    class="step-button p-4 rounded-xl font-bold text-lg ${data.color} ${isActive ? 'active-selection' : ''}">
                ${data.icon} ${data.name}
            </button>
        `;
    });
    showStepContent(1);
};

const selectPlatform = (key) => {
    currentOrder.platform = key;
    currentOrder.service = null; // Reset service when platform changes
    renderPlatforms(); // To show active state on platform buttons
    renderServices();
};

// --- Step 2: Service Selection ---
const renderServices = () => {
    const container = document.getElementById('service-buttons');
    container.innerHTML = '';
    const platformKey = currentOrder.platform;
    const platformData = servicesData[platformKey];

    // Agar platform 'more' hai, toh usmein sirf ek service hai
    if (platformKey === 'more') {
        const serviceKey = 'other_service'; // 'more' ke liye hardcoded key
        const serviceData = platformData.services[serviceKey];
        container.innerHTML += `
            <button onclick="selectService('${serviceKey}')"
                    class="step-button p-4 rounded-xl text-gray-800 border-2 border-yellow-300 bg-yellow-50 font-semibold hover:bg-yellow-200">
                ${platformData.icon} ${serviceData.label} (Next Step Par Detail Daalein)
            </button>
        `;
    } else {
        Object.keys(platformData.services).forEach(key => {
            const serviceData = platformData.services[key];
            const isActive = currentOrder.service === key;
            container.innerHTML += `
                <button onclick="selectService('${key}')"
                        class="step-button p-4 rounded-xl text-gray-800 border-2 border-yellow-300 bg-yellow-50 font-semibold hover:bg-yellow-200 ${isActive ? 'active-selection' : ''}">
                    ${platformData.icon} ${serviceData.label}
                </button>
            `;
        });
    }
    
    showStepContent(2);
};

const selectService = (key) => {
    currentOrder.service = key;
    renderForm();
};

// --- Step 3: Order Form ---
const renderForm = () => {
    const pKey = currentOrder.platform;
    const sKey = currentOrder.service;
    if (!pKey || !sKey) return;

    const pData = servicesData[pKey];
    const sData = pData.services[sKey];

    // Update Summary
    document.getElementById('selected-summary').innerHTML = `
        👉 <span class="font-bold text-blue-600">${pData.name}</span> selected: <span class="font-bold text-green-600">${sData.label}</span>
    `;
    
    // Update Link Prompt
    document.getElementById('link-label').textContent = `${sData.prompt} Yahan Daalein:`;

    // Agar 'more' service hai, toh Link ka field thoda bada kar dein for more detail
    const linkInput = document.getElementById('order-link');
    if (pKey === 'more') {
        linkInput.placeholder = 'Social Media Naam, Service Type (Followers/Likes), aur Link Yahan Daalein';
    } else {
        // Reset placeholder for other services
        linkInput.placeholder = 'https://example.com/link_here'; 
    }

    showStepContent(3);
};

// --- Order Placement ---
const placeOrder = () => {
    const linkInput = document.getElementById('order-link');
    const quantityInput = document.getElementById('order-quantity');
    
    const link = linkInput.value.trim();
    const quantity = parseInt(quantityInput.value, 10);
    
    if (!link || quantity < 100 || quantityInput.value.trim() === '') {
        showCustomMessage('Error ❌', 'Kripya sahi link aur quantity (Minimum 100) bharein.', 'text-red-600');
        return;
    }

    const pData = servicesData[currentOrder.platform];
    const sData = pData.services[currentOrder.service];

    // 1. Construct the Order Message
    let orderMessage = '';
    if (currentOrder.platform === 'more') {
         // Agar 'More' service hai, toh message mein 'Service' field mein puri detail daal denge
         orderMessage = 
        `*--- NEW CUSTOM SMM ORDER REQUEST ---*
Platform: ${pData.name} (${pData.icon})
Service Details (Platform/Type/Link): ${link}
Quantity: ${quantity}
*--------------------------------*`;
    } else {
        // Normal order
        orderMessage = 
        `*--- NEW SMM ORDER REQUEST ---*
Platform: ${pData.name} (${pData.icon})
Service: ${sData.label}
Link: ${link}
Quantity: ${quantity}
*--------------------------------*`;
    }

    // 2. Copy to Clipboard (using fallback method for iFrame compatibility)
    copyToClipboard(orderMessage);
    
    // 3. Show confirmation box
    document.getElementById('message-box').classList.remove('hidden');

    // 4. Redirect to Messenger after a short delay
    setTimeout(() => {
        window.location.href = messengerLink;
    }, 1500);
};

const copyToClipboard = (text) => {
    // Creates a temporary textarea element to copy the text.
    const el = document.createElement('textarea');
    el.value = text;
    el.setAttribute('readonly', '');
    el.style.position = 'absolute';
    el.style.left = '-9999px';
    document.body.appendChild(el);
    el.select();
    try {
        // Fallback for iFrame restrictions
        document.execCommand('copy');
    } catch (err) {
        console.error('Could not copy text: ', err);
        showCustomMessage('Error', 'Copy nahi ho paya. Kripya details manually copy karein.', 'text-red-600');
    }
    document.body.removeChild(el);
};

const resetOrder = (step) => {
    currentOrder.service = null;
    document.getElementById('order-link').value = '';
    document.getElementById('order-quantity').value = 100;
    if (step === 1) {
        currentOrder.platform = null;
        renderPlatforms();
    } else if (step === 2) {
        renderServices();
    }
};

const showCustomMessage = (title, message, titleColorClass) => {
    const box = document.getElementById('message-box');
    box.querySelector('h4').textContent = title;
    box.querySelector('h4').className = `text-xl font-bold mb-4 ${titleColorClass}`;
    box.querySelector('p').textContent = message;
    box.classList.remove('hidden');
};

// --- Initialization ---
document.addEventListener('DOMContentLoaded', () => {
    // The app starts on the landing view. The JS only runs when buttons are clicked.
});
